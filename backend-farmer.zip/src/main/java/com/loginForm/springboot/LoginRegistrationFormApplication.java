package com.loginForm.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginRegistrationFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginRegistrationFormApplication.class, args);
	}

}
