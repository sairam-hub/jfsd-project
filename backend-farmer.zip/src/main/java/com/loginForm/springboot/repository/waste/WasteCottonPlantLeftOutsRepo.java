package com.loginForm.springboot.repository.waste;

//import com.api.create.Models.WasteCottonPlantLeftOuts;
import com.loginForm.springboot.model.waste.WasteCottonPlantLeftOuts;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WasteCottonPlantLeftOutsRepo extends JpaRepository<WasteCottonPlantLeftOuts, Long> {
}
