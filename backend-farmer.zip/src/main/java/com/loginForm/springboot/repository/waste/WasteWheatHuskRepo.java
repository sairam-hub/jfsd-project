package com.loginForm.springboot.repository.waste;

//import com.api.create.Models.WasteWheatHusk;
import com.loginForm.springboot.model.waste.WasteWheatHusk;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WasteWheatHuskRepo extends JpaRepository<WasteWheatHusk, Long> {
}
