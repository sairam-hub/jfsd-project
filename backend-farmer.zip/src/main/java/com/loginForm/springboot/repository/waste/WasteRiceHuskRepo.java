package com.loginForm.springboot.repository.waste;

import com.loginForm.springboot.model.waste.WasteRiceHusk;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WasteRiceHuskRepo extends JpaRepository<WasteRiceHusk, Long> {
}
