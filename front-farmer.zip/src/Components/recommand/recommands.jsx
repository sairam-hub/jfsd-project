import React, { useState, useEffect } from 'react';
import './Recommand.css'
const Recommand = () => {
  const [crops, setCrops] = useState([]);

  useEffect(() => {
    const fetchedCrops = [
      {
        name: 'Rice',
        season: 'Monsoon',
        soil: 'Clay',
        water: 'High',
        sunlight: 'Full Sun',
        growth: 'Long-term',
        description: 'Rice grows in the monsoon season with clay soil, requiring abundant water and full sunlight.'
      },
      {
        name: 'Wheat',
        season: 'Winter',
        soil: 'Loamy',
        water: 'Moderate',
        sunlight: 'Full Sun',
        growth: 'Medium-term',
        description: 'Wheat is grown in loamy soil in winter, requiring moderate water and full sunlight.'
      },
      {
        name: 'Cotton',
        season: 'Summer',
        soil: 'Sandy',
        water: 'Low',
        sunlight: 'Full Sun',
        growth: 'Long-term',
        description: 'Cotton thrives in the summer with sandy soil and low water needs, requiring full sunlight.'
      },
      {
        name: 'Barley',
        season: 'Autumn',
        soil: 'Silty',
        water: 'Low',
        sunlight: 'Partial Sun',
        growth: 'Medium-term',
        description: 'Barley grows best in silty soil in autumn, requiring low water and partial sunlight.'
      }
    ];
    setCrops(fetchedCrops);
  }, []);

  return (
    <div className="recommendation-container">
      <h1 className="title">Crop Recommendations Based on Various Factors</h1>
      
     
      <section className="section" style={{ backgroundColor: '#fce4ec' }}>
        <h2 className="section-title">Based on Seasons</h2>
        <div className="crop-list">
          {crops.filter(crop => crop.season === 'Monsoon').map((crop, index) => (
            <div className="crop-card" key={index}>
              <h3 className="crop-name">{crop.name}</h3>
              <p className="crop-description">{crop.description}</p>
            </div>
          ))}
        </div>
      </section>

     
      <section className="section" style={{ backgroundColor: '#e8f5e9' }}>
        <h2 className="section-title">Based on Soil Types</h2>
        <div className="crop-list">
          {crops.filter(crop => crop.soil === 'Clay').map((crop, index) => (
            <div className="crop-card" key={index}>
              <h3 className="crop-name">{crop.name}</h3>
              <p className="crop-description">{crop.description}</p>
            </div>
          ))}
        </div>
      </section>

      
      <section className="section" style={{ backgroundColor: '#bbdefb' }}>
        <h2 className="section-title">Based on Water Requirements</h2>
        <div className="crop-list">
          {crops.filter(crop => crop.water === 'High').map((crop, index) => (
            <div className="crop-card" key={index}>
              <h3 className="crop-name">{crop.name}</h3>
              <p className="crop-description">{crop.description}</p>
            </div>
          ))}
        </div>
      </section>

     
      <section className="section" style={{ backgroundColor: '#fff3e0' }}>
        <h2 className="section-title">Based on Sunlight Requirements</h2>
        <div className="crop-list">
          {crops.filter(crop => crop.sunlight === 'Full Sun').map((crop, index) => (
            <div className="crop-card" key={index}>
              <h3 className="crop-name">{crop.name}</h3>
              <p className="crop-description">{crop.description}</p>
            </div>
          ))}
        </div>
      </section>

    
      <section className="section" style={{ backgroundColor: '#e1bee7' }}>
        <h2 className="section-title">Based on Growth Duration</h2>
        <div className="crop-list">
          {crops.filter(crop => crop.growth === 'Long-term').map((crop, index) => (
            <div className="crop-card" key={index}>
              <h3 className="crop-name">{crop.name}</h3>
              <p className="crop-description">{crop.description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Recommand;
